package br.com.fiap.cultiva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CultivaApplicationTests {

	@Test
	void contextLoads() {
	}

}
